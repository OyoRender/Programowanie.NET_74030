﻿using System.Windows;

namespace MediaApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MediaViewModel();
        }
    }
}
