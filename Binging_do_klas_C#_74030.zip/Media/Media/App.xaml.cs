﻿using System.Windows;

namespace MediaApp
{
    public partial class App : Application
    {
    }
}
