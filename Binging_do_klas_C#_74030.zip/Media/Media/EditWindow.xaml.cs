﻿using System.Windows;

namespace MediaApp
{
    public partial class EditWindow : Window
    {
        public EditWindow(MediaItem mediaItem)
        {
            InitializeComponent();
            DataContext = mediaItem;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
