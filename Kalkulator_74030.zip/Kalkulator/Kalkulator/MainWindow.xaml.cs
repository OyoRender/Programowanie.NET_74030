﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Data; // Dodajemy przestrzeń nazw dla DataTable

namespace Kalkulator
{
    public partial class MainWindow : Window
    {
        private string currentValue = "";
        private string currentOperation = "";
        private bool isNewValue = false;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string content = button.Content.ToString();

            switch (content)
            {
                case "sqrt":
                    currentResultTextBox.Text = Math.Sqrt(double.Parse(currentResultTextBox.Text)).ToString();
                    isNewValue = true;
                    break;
                case "log":
                    currentResultTextBox.Text = Math.Log10(double.Parse(currentResultTextBox.Text)).ToString();
                    isNewValue = true;
                    break;
                case "ln":
                    currentResultTextBox.Text = Math.Log(double.Parse(currentResultTextBox.Text)).ToString();
                    isNewValue = true;
                    break;
                case "abs":
                    currentResultTextBox.Text = Math.Abs(double.Parse(currentResultTextBox.Text)).ToString();
                    isNewValue = true;
                    break;
                case "=":
                    try
                    {
                        // Obliczanie wyniku na podstawie zawartości resultTextBox
                        currentResultTextBox.Text = new DataTable().Compute(resultTextBox.Text, null).ToString();
                        isNewValue = true;
                    }
                    catch (Exception ex)
                    {
                        // Obsługa błędów
                        currentResultTextBox.Text = "Error";
                        Console.WriteLine(ex.Message);
                    }
                    break;
                default:
                    if (isNewValue)
                    {
                        resultTextBox.Text = content;
                        currentResultTextBox.Text = content;
                        isNewValue = false;
                    }
                    else
                    {
                        resultTextBox.Text += content;
                        currentResultTextBox.Text += content;
                    }
                    break;
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            resultTextBox.Text = "";
            currentResultTextBox.Text = "0";
            currentValue = "";
            currentOperation = "";
            isNewValue = false;
        }

        private void RemoveLastDigit()
        {
            if (resultTextBox.Text.Length > 0)
            {
                resultTextBox.Text = resultTextBox.Text.Substring(0, resultTextBox.Text.Length - 1);
                currentResultTextBox.Text = resultTextBox.Text;
            }
        }
    }
}
